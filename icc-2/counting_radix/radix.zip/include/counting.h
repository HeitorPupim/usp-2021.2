#ifndef COUNTING_H
#define COUNTING_H

#include <util.h>
void countingSort(int *v, int numElem, int kE);

#endif