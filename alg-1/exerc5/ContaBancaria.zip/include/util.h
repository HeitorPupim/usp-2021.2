#ifndef UTIL_H
#define UTIL_H

#define BUFFER 16
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


char* readline(char parada);
char *readCPF(char parada);

#endif