#ifndef UTIL_H
#define UTIL_H

#include <stdio.h>
#include <stdlib.h>

char* readline(char parada);

#endif //UTIL_H